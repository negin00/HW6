 //نگین عینی پور-40223056
 #include <stdio.h>
 #include <math.h>
int count;
void solver(double, double, double, double*, double*);

int main()
{
double a,b,c;
printf("Please enter a number: ");
scanf("%lf%lf%lf",&a,&b,&c);
if((a==0) && (b==0))
    printf("Invalid Inputs!");
else
{
    double x,y;
    double *p1=&x, *p2=&y;
    solver(a,b,c,p1,p2);
    if(count==2)
        printf("The number of roots is: %d\nThe roots are: %lf,%lf",count,*p1,*p2);
    else if(count==1)
        printf("The number of roots is: %d\nThe root is : %lf",count,*p1);
    else if(count==0)
        printf("\"This equation has no real roots\"");
}
}


void solver(double a, double b, double c, double *rishe1, double *rishe2)
{
double delta=sqrt((b*b)-4*a*c);
if(delta>0)
{
    count=2;
    *rishe1=((-b)+delta)/(2*a);
    *rishe2=((-b)-delta)/(2*a);
}
else if(delta==0)
{
    count=1;
    *rishe1=(-b)/(2*a);
}
else
    count=0;
 }